package com.example.covid19

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class Information : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_information)


        val titulo = findViewById<TextView>(R.id.txtTitulo)
        val info = findViewById<TextView>(R.id.txtInfo)

        val com = findViewById<Button>(R.id.btnCom)
        val comment = findViewById<TextView>(R.id.txtCom)
        val comentario: String = comment.toString()

        var tituloActivity: String = intent.getStringExtra("Titulo")
        var infoActivity: String = intent.getStringExtra("Datos")

        titulo.text = tituloActivity
        info.text = infoActivity

        com.setOnClickListener{
            if(comentario != null){
                val intent = Intent(this,MainActivity::class.java)
                intent.putExtra("Comentario",comentario)
                startActivity(intent)
                finish()
            }else{
                Toast.makeText(this,"Comentario invalido",Toast.LENGTH_SHORT).show()
            }

        }

    }
}
