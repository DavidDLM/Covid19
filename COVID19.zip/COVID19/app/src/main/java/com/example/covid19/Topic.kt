package com.example.covid19

data class Topic(val titulo: String, val informacion: String)
