package com.example.covid19

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Layout.JUSTIFICATION_MODE_INTER_WORD
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val riesgo = findViewById<Button>(R.id.btnRiesgo)
        val txtnombre = findViewById<TextView>(R.id.txtNombre)
        val txtedad = findViewById<TextView>(R.id.txtEdad)
        val txtInfo = findViewById<TextView>(R.id.textView5)

        val virus = findViewById<Button>(R.id.btnVirus)
        val indicaciones = findViewById<Button>(R.id.btnIndicaciones)
        val sintomas = findViewById<Button>(R.id.btnSint)

        val txtNomRes = findViewById<TextView>(R.id.txtNom)
        val txtRiesgoRes = findViewById<TextView>(R.id.txtRiesgo)

        txtnombre.bringToFront()
        txtedad.bringToFront()
        riesgo.bringToFront()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            txtInfo.justificationMode = JUSTIFICATION_MODE_INTER_WORD
        }

/*
        try{
            var tituloActivity: String = intent.getStringExtra("Comentario")
            Toast.makeText(this,tituloActivity,Toast.LENGTH_SHORT).show()
        }catch(e: Exception){
            return
        }

*/


        riesgo.setOnClickListener{
            val nombre = txtnombre.text.toString()
            val edad = txtedad.text.toString().toInt()

            if(edad in 0..125){
                calcularRiesgo(edad,nombre,txtnombre,txtedad,txtNomRes,txtRiesgoRes)
            }else{
                Toast.makeText(this,"Edad debe estar entre 0 y 125 años",Toast.LENGTH_SHORT).show()
            }

        }

        sintomas.setOnClickListener{
            val titulo1: String = "Sintomas"
            val sint: String = "Síntomas comunes: fiebre, cansancio, tos seca. " +
                    "Algunas personas también pueden experimentar: dolores y molestias, congestión nasal, " +
                    "abundante secreción nasal, dolor de garganta, diarrea. " +
                    "Cuando una persona se infecta con el virus, los síntomas tardan en aparecer en término " +
                    "medio de 5 a 6 días, pero pueden tardar hasta 14 días. Las personas con síntomas leves que, " +
                    "por lo demás, estén sanas deberían aislarse. Solicite atención médica si tiene fiebre, tos y " +
                    "dificultad para respirar. Llame con antelación."
            val intent = Intent(this,Information::class.java)
            intent.putExtra("Titulo",titulo1)
            intent.putExtra("Datos",sint)
            startActivity(intent)
        }

        virus.setOnClickListener{
            val titulo1: String = "Virus"
            val sint: String = "COVID-19 (acrónimo del inglés coronavirus disease 2019)," +
                    "también conocida como enfermedad por coronavirus, incorrectamente, como neumonía por coronavirus, " +
                    "es una enfermedad infecciosa causada por el virus SARS-CoV-2." +
                    "Se detectó por primera vez en la ciudad china de Wuhan (provincia de Hubei), en diciembre de 2019." +
                    " Habiendo llegado a más de 100 territorios, el 11 de marzo de 2020 la Organización Mundial de la Salud la declaró pandemia."
            val intent = Intent(this,Information::class.java)
            intent.putExtra("Titulo",titulo1)
            intent.putExtra("Datos",sint)
            startActivity(intent)
        }

        indicaciones.setOnClickListener{
            val titulo1: String = "Indicaciones para prevencion"
            val sint: String = "Para evitar la propagación de la COVID-19: " +
                    "Lávese las manos con frecuencia. Use agua y jabón o un desinfectante de manos a base de alcohol. " +
                    "Manténgase a una distancia segura de cualquier persona que tosa o estornude. " +
                    "No se toque los ojos, la nariz o la boca. Cuando tosa o estornude, cúbrase la nariz y la boca con el codo flexionado o con un pañuelo. " +
                    "Quédese en casa si se siente mal. Si tiene fiebre, tos y dificultad para respirar, solicite atención médica. " +
                    "Llame con antelación. Siga las instrucciones de su organismo sanitario local. " +
                    "Evitar las visitas innecesarias a los centros de atención médica permite que los sistemas sanitarios funcionen con mayor eficacia, " +
                    "lo que redunda en su protección y en la de los demás."
            val intent = Intent(this,Information::class.java)
            intent.putExtra("Titulo",titulo1)
            intent.putExtra("Datos",sint)
            startActivity(intent)
        }

    }


    private fun calcularRiesgo(edad: Int, nombre: String, txtNombre: TextView, txtEdad: TextView, txtNomRes: TextView, txtRiesgoRes:  TextView){
        txtNombre.toggleVisibility()
        txtEdad.toggleVisibility()

        if(txtEdad.visibility == View.INVISIBLE && txtEdad.visibility == View.INVISIBLE){
            txtNomRes.text = nombre
            when (edad){
                in 0..9 -> txtRiesgoRes.text = "Se encuentra en bajo riesgo si contrae el virus."
                in 10..19 -> txtRiesgoRes.text = "Se encuentra en bajo riesgo si contrae el virus."
                in 20..29 -> txtRiesgoRes.text = "Se encuentra en moderado-bajo riesgo si contrae el virus."
                in 30..39 -> txtRiesgoRes.text = "Se encuentra en moderado riesgo si contrae el virus."
                in 40..49 -> txtRiesgoRes.text = "Se encuentra en moderado-alto riesgo si contrae el virus."
                in 50..59 -> txtRiesgoRes.text = "Se encuentra en alto riesgo si contrae el virus."
                in 60..69 -> txtRiesgoRes.text = "Se encuentra en alto riesgo si contrae el virus."
                in 70..79 -> txtRiesgoRes.text = "Se encuentra en riesgo muy alto si contrae el virus."
                in 80..125 -> txtRiesgoRes.text = "Se encuentra en riesgo altisimo si contrae el virus."

            }
        }else if(txtEdad.visibility == View.VISIBLE && txtEdad.visibility == View.VISIBLE){
            txtNomRes.text = ""
            txtRiesgoRes.text = ""
        }

    }

    private fun View.toggleVisibility() {
        this.visibility = if (this.visibility == View.VISIBLE) View.INVISIBLE else View.VISIBLE
    }

}
